export const tablehead = [
      {
        name: "username",
        padding: "pe-2",
        align: "left",
      },
      {
        name: "name",
        padding: "px-2",
        align: "left",
      },
      {
        name: "product",
        padding: "px-2",
        align: "left",
      },
      {
        name: "status",
        padding: "px-2",
        align: "left",
      },
      {
        name: "Quantity",
        padding: "px-2",
        align: "left",
      },
      {
        name: "Total Sales",
        padding: "px-2",
        align: "left",
      },
      {
        name: "date ordered",
        padding: "ps-2",
        align: "left",
      },
      // {
      //   name: "action",
      //   padding: "ps-2",
      //   align: "center",
      // }
    ];
// @mui material components
import Grid from "@mui/material/Grid";

// React components
import SoftBox from "components/SoftBox";

// React examples
import ProfileInfoCard from "essentials/Cards/InfoCards/ProfileInfoCard";
import { useDashboardData } from "layouts/dashboard/data/dashboardRedux";

function Information() {
  const {authUser, loadAuthUser} = useDashboardData({
    authUser: true, 
    otherStats: false, 
    sales: false
  }, []);

  return (
    <>  
      <SoftBox mt={5} mb={3} px={3}>
        <SoftBox p={4} className="shadow-sm rounded-4 bg-white" >
          <Grid container spacing={2}>
            <Grid item xs={12} md={6} xl={4}>
              <ProfileInfoCard
                title="Personal Information"
                info={{
                  Firstname: authUser.firstname,
                  Middlename: authUser.middlename == null ? " " : authUser.middlename,
                  Lastname: authUser.lastname,
                  Suffix: authUser.title == null ? " " : authUser.title,
                  Age: authUser.age,
                  Gender: authUser.mygender,
                  Birthplace: authUser.birthplace,
                  Civil_Status: authUser.myCivilStatus,
                  Birthdate: authUser.myBirthdate,
                  Work: authUser.work == null ? " " : authUser.work,
                  Religion: authUser.religion == null ? " " : authUser.religion,
                }}
              />
            </Grid>
            <Grid item xs={12} md={6} xl={4}>
              <ProfileInfoCard
                title="More Information"
                info={{
                  Mother: authUser.mother == null ? " " : authUser.mother,
                  Father: authUser.father == null ? " " : authUser.father,
                  Siblings: authUser.siblings,
                  Major: authUser.major == null ? " " : authUser.major,
                  School: authUser.school == null ? " " : authUser.school,
                  Mobile: authUser.contact == null ? " " : authUser.contact,
                  Email: authUser.email == null ? " " : authUser.email,
                  Solo_Parent: authUser.solo_parent == 1 ? "Yes" : "No",
                  PWD: authUser.pwd == 1 ? "Yes" : "No",
                  Disabilty: authUser.pwd_detail == null ? " " : authUser.pwd_detail,
                  House_No: authUser.house_no == null ? " " : authUser.house_no,
                }}
              />
            </Grid>
            <Grid item xs={12} xl={4}>
            <ProfileInfoCard
                title="Account Information"
                info={{
                  Account_Status: authUser.account_status == 1 ? "Active" : "Inactive",
                  Date_Added: authUser.date_added,
                  Residency_Status: authUser.residency_status == 1 ? "Active" : "Inactive",
                  Year_Residency: authUser.year_residency,
                  Last_Online: authUser.last_online,
                  Death_Date: authUser.myDeathdate == null ? " " : authUser.deathdate,
                }}
              />
            </Grid>
          </Grid>
        </SoftBox>
      </SoftBox>
    </>
  );
}

export default Information;

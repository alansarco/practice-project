// React components
import { Checkbox, Grid, Icon, Select, Switch } from "@mui/material";
import FixedLoading from "components/General/FixedLoading";
import SoftBox from "components/SoftBox";
import SoftButton from "components/SoftButton";
import SoftInput from "components/SoftInput";
import SoftTypography from "components/SoftTypography";
import { civilSelect, genderSelect, years, currentDate } from "components/General/Utils";
import { useEffect, useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import { messages } from "components/General/Messages";
import { useStateContext } from "context/ContextProvider";
import { passToErrorLogs, passToSuccessLogs  } from "components/Api/Gateway";
import axios from "axios";
import { apiRoutes } from "components/Api/ApiRoutes";

function areRequiredFieldsFilled(formData) {
      const requiredFields = [
            "firstname",
            "lastname",
            "birthplace",
            "birthdate",
            "gender",
            "civil_status",
            "year_residency",
      ];
      
      for (const field of requiredFields) {
            if (!formData[field]) {
                  return false;
            }
      }
      return true;
}
      
function Edit({authUser, suffixList, setProfile }) {
      const currentFileName = "layouts/profile/components/Edit/index.js";
      
      const [submitProfile, setSubmitProfile] = useState(false);

      const {token} = useStateContext();  

      const YOUR_ACCESS_TOKEN = token; 
      const headers = {
            'Authorization': `Bearer ${YOUR_ACCESS_TOKEN}`
      };

      const initialState = {
            username: authUser.username,
            firstname: authUser.firstname,
            middlename: authUser.middlename == null ? "" : authUser.middlename,
            lastname: authUser.lastname,
            suffix: authUser.suffix == null ? "0" : authUser.suffix,
            birthplace: authUser.birthplace,
            birthdate: authUser.birthdate,
            gender: authUser.gender,
            work: authUser.work == null ? "" : authUser.work,
            religion: authUser.religion == null ? "" : authUser.religion,
            civil_status: authUser.civil_status,
            solo_parent: authUser.solo_parent == 1 ? true : false,
            pwd: authUser.pwd == 1 ? true : false,
            pwd_detail: authUser.pwd_detail == null ? "" : authUser.pwd_detail,
            major: authUser.major == null ? "" : authUser.major,
            school: authUser.school == null ? "" : authUser.school,      
            email: authUser.email == null ? "" : authUser.email,
            contact: authUser.contact == null ? "" : authUser.contact,
            father: authUser.father == null ? "" : authUser.father,                 
            mother: authUser.mother == null ? "" : authUser.mother,
            siblings: authUser.siblings  == null ? "0" : authUser.siblings,
            house_no: authUser.house_no == null ? "" : authUser.house_no,
            year_residency: authUser.year_residency,
            isDead: authUser.deathdate == null ? false : true,
            deathdate: authUser.deathdate == null ? "" : authUser.deathdate,
            residency_status: authUser.residency_status == 1 ? true : false,
            account_status: authUser.account_status == 1 ? true : false,   
            agreement: false,   
      };

      const [formData, setFormData] = useState(initialState);

      const handleChange = (e) => {
            const { name, value, type } = e.target;
            if (type === "checkbox") {
                  setFormData({ ...formData, [name]: !formData[name]});
            } else {
                  setFormData({ ...formData, [name]: value });
            }
      };

      const handleCancel = () => {
            setProfile();
      };
            
      const handleSubmit = async (e) => {
            e.preventDefault(); 
            toast.dismiss();
             // Check if all required fields are empty
             const requiredFields = [
                  "username", 
                  "firstname", 
                  "lastname", 
                  "birthplace", 
                  "birthdate", 
                  "gender", 
                  "civil_status", 
                  "year_residency"
            ];
            const emptyRequiredFields = requiredFields.filter(field => !formData[field]);

            if (emptyRequiredFields.length === 0) {
                  if(formData.isDead && !formData.deathdate) {
                        toast.warning(messages.required, { autoClose: true });
                  }
                  else if(!formData.agreement) {
                        toast.warning(messages.agreement, { autoClose: true });
                  }
                  else {      
                        setSubmitProfile(true);
                        try {
                              if (!token) {
                                    toast.error(messages.prohibit, { autoClose: true });
                              }
                              else {  
                                    const response = await axios.post(apiRoutes.accountUpdate, formData, {headers});
                                    if(response.data.status == 200) {
                                          toast.success(`${response.data.message}`, { autoClose: true });
                                    } else {
                                          toast.error(`${response.data.message}`, { autoClose: true });
                                    }
                                    passToSuccessLogs(response.data, currentFileName);
                              }
                        } catch (error) { 
                              toast.error(messages.updateUserError, { autoClose: true });
                              passToErrorLogs(error, currentFileName);
                        }     
                        setSubmitProfile(false);
                  }
                  
            } else {
                  // Display an error message or prevent form submission
                  toast.warning(messages.required, { autoClose: true });
            }
      };

      return (  
      <>
            {submitProfile && <FixedLoading />}
            <SoftBox mt={5} mb={3} px={3}>      
                  <SoftBox mb={5} p={4} className="shadow-sm rounded-4 bg-white">
                        <SoftTypography variant="h6" fontWeight="medium" textTransform="capitalize" className="text-info text-gradient text-uppercase">
                              Direction!
                        </SoftTypography>
                        <SoftTypography fontWeight="bold" className="text-xs">
                              Please fill in the required fields. Rest assured that your data is secured.     
                        </SoftTypography> 
                        <SoftBox mt={2}>
                              <SoftBox component="form" role="form" className="px-md-0 px-2" onSubmit={handleSubmit}>
                                    <SoftTypography fontWeight="medium" textTransform="capitalize" color="warning" textGradient>
                                          Personal Information    
                                    </SoftTypography>
                                    <input type="hidden" name="username" value={formData.username} size="small" /> 
                                    <Grid container spacing={0} alignItems="center">
                                          <Grid item xs={12} md={4} px={1}>
                                                <SoftTypography variant="button" className="me-1">Firstname:</SoftTypography>
                                                <SoftTypography variant="span" className="text-xxs text-danger fst-italic">*</SoftTypography>
                                                <SoftInput name="firstname" value={formData.firstname} onChange={handleChange} size="small" /> 
                                          </Grid>
                                          <Grid item xs={12} md={4} px={1}>
                                                <SoftTypography variant="button" className="me-1"> Middlename:</SoftTypography>
                                                <SoftInput name="middlename" value={formData.middlename} onChange={handleChange} size="small" /> 
                                          </Grid>
                                          <Grid item xs={12} md={4} px={1}>
                                                <SoftTypography variant="button" className="me-1"> Surname: </SoftTypography>
                                                <SoftTypography variant="span" className="text-xxs text-danger fst-italic">*</SoftTypography>
                                                <SoftInput name="lastname" value={formData.lastname} onChange={handleChange} size="small" /> 
                                          </Grid>           
                                          <Grid item xs={12} md={2} px={1}>
                                                <SoftTypography variant="button" className="me-1"> Suffix: </SoftTypography>
                                                <select className="form-control form-select form-select-sm text-secondary rounded-5 cursor-pointer" name="suffix" value={formData.suffix} onChange={handleChange}>
                                                      <option value="0">  None </option>  
                                                      {suffixList.map((suffix) => (
                                                      <option key={suffix.id} value={suffix.id}>
                                                            {suffix.title}
                                                      </option>
                                                      ))}
                                                </select> 
                                          </Grid>
                                          <Grid item xs={12} md={6} px={1}>
                                                <SoftTypography variant="button" className="me-1"> Birthplace: </SoftTypography>
                                                <SoftTypography variant="span" className="text-xxs text-danger fst-italic">*</SoftTypography>
                                                <SoftInput name="birthplace" value={formData.birthplace} onChange={handleChange} size="small" /> 
                                          </Grid>  
                                          <Grid item xs={12} md={4} px={1}>
                                                <SoftTypography variant="button" className="me-1"> Birthdate: </SoftTypography>
                                                <SoftTypography variant="span" className="text-xxs text-danger fst-italic">*</SoftTypography>
                                                <input className="form-control form-control-sm text-secondary rounded-5"  max={currentDate} name="birthdate" value={formData.birthdate} onChange={handleChange} type="date" />
                                          </Grid>
                                          <Grid item xs={12} md={2} px={1}>
                                                <SoftTypography variant="button" className="me-1"> Gender: </SoftTypography>
                                                <SoftTypography variant="span" className="text-xxs text-danger fst-italic">*</SoftTypography>
                                                <select className="form-control form-select form-select-sm text-secondary rounded-5 cursor-pointer" name="gender" value={formData.gender} onChange={handleChange} >
                                                      {genderSelect.map((gender) => (
                                                      <option key={gender.value} value={gender.value}>
                                                            {gender.desc}
                                                      </option>
                                                      ))}
                                                </select>
                                          </Grid>
                                          <Grid item xs={12} lg={4} md={6} px={1}>
                                                <SoftTypography variant="button" className="me-1"> Work: </SoftTypography>
                                                <SoftInput name="work" value={formData.work} onChange={handleChange} size="small" /> 
                                          </Grid>  
                                          <Grid item xs={12} lg={4} md={4} px={1}>
                                                <SoftTypography variant="button" className="me-1"> Religion: </SoftTypography>
                                                <SoftInput name="religion" value={formData.religion} onChange={handleChange} size="small" /> 
                                          </Grid>  
                                          <Grid item xs={12} lg={2} md={3} px={1}>
                                                <SoftTypography variant="button" className="me-1"> Civil Status: </SoftTypography>
                                                <SoftTypography variant="span" className="text-xxs text-danger fst-italic">*</SoftTypography>
                                                <select className="form-control form-select form-select-sm text-secondary rounded-5 cursor-pointer" name="civil_status" value={formData.civil_status} onChange={handleChange}>
                                                      {civilSelect.map((civil) => (
                                                      <option key={civil.value} value={civil.value}>
                                                            {civil.desc}
                                                      </option>
                                                      ))}
                                                </select>
                                          </Grid>  
                                          <Grid item xs={12} md={2} px={1}>
                                                <SoftTypography variant="button" className="me-1"> Solo Parent: </SoftTypography>
                                                <Switch name="solo_parent" checked={formData.solo_parent} onChange={handleChange} />
                                          </Grid>
                                          <Grid item xs={12} md={2} px={1}>
                                                <SoftTypography variant="button" className="me-1"> PWD: </SoftTypography>
                                                <Switch name="pwd" checked={formData.pwd} onChange={handleChange} />
                                                
                                          </Grid> 
                                          {formData.pwd == 1 && 
                                          <Grid item xs={12} md={5} px={1}>
                                                <SoftTypography variant="button" className="me-1"> Specify your disability: </SoftTypography>
                                                <SoftInput name="pwd_detail" value={formData.pwd_detail} onChange={handleChange} size="small" /> 
                                          </Grid>
                                          }
                                    </Grid>
                                    <SoftTypography mt={2} fontWeight="medium" textTransform="capitalize" color="warning" textGradient>
                                          Contact Information
                                    </SoftTypography>
                                    <Grid container spacing={0} alignItems="center">
                                          <Grid item xs={12} md={4} px={1}>
                                                <SoftTypography variant="button" className="me-1">Email:</SoftTypography>
                                                <SoftInput name="email" value={formData.email} onChange={handleChange} size="small" /> 
                                          </Grid>
                                          <Grid item xs={12} md={4} px={1}>
                                                <SoftTypography variant="button" className="me-1"> Phone Number: </SoftTypography>
                                                <SoftInput name="contact" value={formData.contact} onChange={handleChange} size="small" /> 
                                          </Grid> 
                                    </Grid>
                                    <SoftTypography mt={2} fontWeight="medium" textTransform="capitalize" color="warning" textGradient>
                                          Family Background    
                                    </SoftTypography>
                                    <Grid container spacing={0} alignItems="center">
                                          <Grid item xs={12} md={6} px={1}>
                                                <SoftTypography variant="button" className="me-1">Father's Fullname:</SoftTypography>
                                                <SoftInput name="father" value={formData.father} onChange={handleChange} size="small" /> 
                                          </Grid>
                                          <Grid item xs={12} md={6} px={1}>
                                                <SoftTypography variant="button" className="me-1">Mother's Fullname: </SoftTypography>
                                                <SoftInput name="mother" value={formData.mother} onChange={handleChange} size="small" /> 
                                          </Grid> 
                                          <Grid item xs={12} md={4} px={1}>
                                                <SoftTypography variant="button" className="me-1">No. of siblings excluding you: </SoftTypography>
                                                <SoftTypography variant="span" className="text-xxs text-danger fst-italic">*</SoftTypography>
                                                <SoftInput name="siblings" value={formData.siblings} onChange={handleChange} type="number" size="small" /> 
                                          </Grid> 
                                    </Grid>
                                    <SoftTypography mt={2} fontWeight="medium" textTransform="capitalize" color="warning" textGradient>
                                          Other Information    
                                    </SoftTypography>
                                    <Grid container spacing={0} alignItems="center">
                                          <Grid item xs={12} md={3} px={1}>
                                                <SoftTypography variant="button" className="me-1">House No:</SoftTypography>
                                                <SoftInput name="house_no" value={formData.house_no} onChange={handleChange} size="small" /> 
                                          </Grid>
                                          <Grid item xs={12} md={3} px={1}>
                                                <SoftTypography variant="button" className="me-1">Year of Residency: </SoftTypography>
                                                <SoftTypography variant="span" className="text-xxs text-danger fst-italic">*</SoftTypography>
                                                <select className="form-control form-select form-select-sm text-secondary rounded-5 cursor-pointer" name="year_residency" value={formData.year_residency} onChange={handleChange}>
                                                      {years.map((year) => (
                                                      <option key={year} value={year}>
                                                            {year}
                                                      </option>
                                                      ))}
                                                </select>
                                          </Grid> 
                                          <Grid item xs={12} md={2} px={1}>
                                                <SoftTypography variant="button" className="me-1">Dead: </SoftTypography>
                                                <SoftTypography variant="span" className="text-xxs text-danger fst-italic">*</SoftTypography>
                                                <Switch name="isDead" checked={formData.isDead} onChange={handleChange} type="checkbox" />
                                          </Grid>  
                                          {formData.isDead &&
                                          <Grid item xs={12} md={4} px={1}>
                                                <SoftTypography variant="button" className="me-1">Deathdate: </SoftTypography>
                                                <input className="form-control form-control-sm text-secondary rounded-5" max={currentDate} name="deathdate" value={formData.deathdate} onChange={handleChange} type="date" /> 
                                          </Grid>
                                          } 
                                    </Grid> 
                                    <Grid mt={3} container spacing={0} alignItems="center">
                                          <Grid item xs={12} pl={1}>
                                                <Checkbox name="agreement" checked={formData.agreement} onChange={handleChange} />
                                                <SoftTypography variant="button" className="me-1 ms-2">Verify Data </SoftTypography>
                                                <SoftTypography variant="p" className="text-xxs text-secondary fst-italic">(Confirming that the information above are accurate) </SoftTypography>
                                                <SoftTypography variant="span" className="text-xxs text-danger fst-italic">*</SoftTypography>
                                          </Grid>
                                    </Grid>
                                    <Grid mt={3} container spacing={0} alignItems="center" justifyContent="end">
                                          <Grid item xs={12} sm={4} md={2} pl={1}>
                                                <SoftBox mt={2} display="flex" justifyContent="end">
                                                      <SoftButton onClick={handleCancel} className="mx-2 w-100" size="small" color="light">
                                                            Back
                                                      </SoftButton>
                                                </SoftBox>
                                          </Grid>
                                          <Grid item xs={12} sm={4} md={2} pl={1}>
                                                <SoftBox mt={2} display="flex" justifyContent="end">
                                                      <SoftButton type="submit" className="mx-2 w-100" size="small" color="dark">
                                                            Save
                                                      </SoftButton>
                                                </SoftBox>
                                          </Grid>
                                    </Grid>     
                              </SoftBox>
                        </SoftBox>
                  </SoftBox>
            </SoftBox>
            <ToastContainer
            position="bottom-right"
            autoClose={false}
            limit={5}
            newestOnTop={false}
            closeOnClick
            rtl={false}
            pauseOnFocusLoss
            draggable={false}
            theme="light"
            />
      </>
      );
}

export default Edit;

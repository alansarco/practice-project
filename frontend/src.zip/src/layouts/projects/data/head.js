export const tablehead = [
      {
        name: "product id",
        padding: "pe-2",
        align: "left",
      },
      {
        name: "product name",
        padding: "px-2",
        align: "left",
      },
      {
        name: "Total Sales",
        padding: "px-2",
        align: "left",
      },
      {
        name: "status",
        padding: "px-2",
        align: "left",
      },
      {
        name: "date added", 
        padding: "ps-2",
        align: "left",
      },
    ];
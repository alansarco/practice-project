export const tablehead = [
    {
      name: "LRN",
      padding: "pe-2",
      align: "left",
    },
    {
      name: "fullname",
      padding: "px-2",
      align: "left",
    },
    {
      name: "gender",
      padding: "px-2",
      align: "left",
    },
    {
      name: "Grade",
      padding: "px-2",
      align: "left",
    },
    {
      name: "contact",
      padding: "ps-2",
      align: "left",
    },
    // {
    //   name: "action",
    //   padding: "ps-2",
    //   align: "center",
    // }
  ];

export const passToSuccessLogs = (message, path) => {
      console.log('Success Response:', message, path);
};

export const passToErrorLogs = (message, path) => {   
      console.log('Error Response:', message, path);
};